package br.com.alura.leilao.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FinalizarLeilaoServiceTest {

	private FinalizarLeilaoService service;
	
	@Test
	void deveriaFinalizarUmLeilao() {
		service = new FinalizaLeilaoService();
	}

}
