package br.com.alura.leilao.service;

public class FinalizaLeilaoService extends FinalizarLeilaoService {

}
